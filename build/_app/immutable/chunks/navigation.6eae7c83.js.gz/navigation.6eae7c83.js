import { k as client_method } from "./singletons.2584eb3f.js";
const goto = /* @__PURE__ */ client_method("goto");
export {
  goto as g
};
