import { k as client_method } from "./singletons.e168a4d6.js";
const goto = /* @__PURE__ */ client_method("goto");
export {
  goto as g
};
