import { k as client_method } from "./singletons.16b38e2a.js";
const goto = /* @__PURE__ */ client_method("goto");
export {
  goto as g
};
