import { k as client_method } from "./singletons.9d706c6d.js";
const goto = /* @__PURE__ */ client_method("goto");
export {
  goto as g
};
